<?php

namespace Model\Repository;

class TagRepository extends Repository
{
}
