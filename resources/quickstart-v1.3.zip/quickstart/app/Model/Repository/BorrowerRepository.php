<?php

namespace Model\Repository;

class BorrowerRepository extends Repository
{
}
