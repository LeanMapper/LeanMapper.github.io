<?php

namespace Model\Repository;

class BookRepository extends Repository
{
}
