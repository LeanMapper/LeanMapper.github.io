<?php

namespace Model\Repository;

class BorrowingRepository extends Repository
{
}
