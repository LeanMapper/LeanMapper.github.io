<?php

namespace Model\Repository;

class AuthorRepository extends Repository
{
}
