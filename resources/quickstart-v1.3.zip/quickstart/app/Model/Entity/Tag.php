<?php

namespace Model\Entity;

use DateTime;

/**
 * @property int $id
 * @property string $name
 */
class Tag extends \LeanMapper\Entity
{
}