<?php

namespace Model\Entity;

class Borrower extends Person
{
}