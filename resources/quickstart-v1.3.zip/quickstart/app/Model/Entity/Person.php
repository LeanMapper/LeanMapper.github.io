<?php

namespace Model\Entity;

/**
 * @property int $id
 * @property string $name
 */
abstract class Person extends \LeanMapper\Entity
{
}
